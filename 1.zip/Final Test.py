#Final Test: This is a program that creates Employee object
#Author: Asjad Ali

from Final import Employee

def main():

    name = str
    hours = round(40,2)

    name = input("Please enter your full name: ")
    social = input("Please enter your social security number: ")
    hours = (float(input("Please enter the number of hours worked: ", )))
    payrate =(float(input("Please enter the payrate per hour: $", )))

    employee = Employee(name, social, hours, payrate, regularpay, overtimehours, overtimerate, overtimepay, grosspay)

    print("Employee's name: ", name)
    print("Social security: ", social)

    if hours <= 40:
        print("Overtime hours: 0")
        print("Overtime pay: $0.00")
        print("Gross pay: $", employee.getRegularpay())

    elif hours > 40:
        print("Regular pay: $", employee.getRegularpay())
        print("Overtime hours: ", employee.getOvertimehours())
        print("Overtime pay: $", employee.getOvertimepay())
        print("Gross pay: $", employee.getGrosspay())

main()

       
