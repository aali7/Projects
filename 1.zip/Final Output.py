Python 3.5.2 (v3.5.2:4def2a2901a5, Jun 25 2016, 22:18:55) [MSC v.1900 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
================ RESTART: C:\Users\COD_User\Downloads\Lab3.py ================
Please enter your full name: Asjad Ali
Please enter your social security number: 2548936712
Please enter the number of hours worked: 120
Please enter the payrate per hour: $15
Employee's name:  Asjad Ali
Social security:  2548936712
Regular pay: $ 1800.0
Overtime hours:  80.0
Overtime pay: $ 1800
Gross pay: $ 3600.0
>>> 
================ RESTART: C:\Users\COD_User\Downloads\Lab3.py ================
Please enter your full name: Sam Smith
Please enter your social security number: 45815456812
Please enter the number of hours worked: 25
Please enter the payrate per hour: $25
Employee's name:  Sam Smith
Social security:  45815456812
Overtime hours: 0
Overtime pay: $0.00
Gross pay: $ 625.0
>>> 
