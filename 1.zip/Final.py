#Final: This is a program that determines gross pay for an employee using a class
#Author: Asjad Ali

class Employee:

    def __init__(self, name, social, hours, payrate, regularpay, overtimehours, overtimerate, overtimepay, grosspay):
        self.__name = name
        self.__social = social
        self.__hours = hours
        self.__payrate = payrate
        self.__regularpay = regularpay
        self.__overtimehours = overtimehours
        self.__overtimerate = overtimerate
        self.__overtimepay = overtimepay
        self.__grosspay = grosspay

    def getName(self):
        return self.__name

    def getSocial(self):
        return self.__social

    def getHours(self):
        return self.__hours
    
    def getPayrate(self):
        return self.__payrate

    def getRegularpay(self):
        return(self.__hours * self.__payrate)
    
    def getOvertimehours(self):
        return(self.__hours - 40.0)

    def getOvertimerate(self):
        return(self.__payrate * 1.5)

    def getOvertimepay(self):
        return (self.__OvertimeHours * self.__OvertimeRate)
    
    def getGrosspay(self):
        return(self.__RegularPay + self.__OvertimePay)
    

    

        
    
